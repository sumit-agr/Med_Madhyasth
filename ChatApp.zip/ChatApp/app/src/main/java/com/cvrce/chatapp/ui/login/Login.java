package com.cvrce.chatapp.ui.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cvrce.chatapp.MainActivity;
import com.cvrce.chatapp.R;
import com.cvrce.chatapp.RegisterActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    private Button lBtn;
    private EditText lemail;
    private EditText lpass;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        lemail = (EditText) findViewById(R.id.login_email);
        lpass = (EditText) findViewById(R.id.login_pass);
        lBtn = (Button)findViewById(R.id.login_btn);
        mAuth = FirebaseAuth.getInstance();

        lBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String loginemail = lemail.getText().toString();
                String loginpass = lpass.getText().toString();

                if(!TextUtils.isEmpty(loginemail)||!TextUtils.isEmpty(loginpass))
                {
                    login_user(loginemail,loginpass);
                }

            }
        });
    }

    private void login_user(String loginemail, String loginpass) {

    mAuth.signInWithEmailAndPassword(loginemail,loginpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
        @Override
        public void onComplete(@NonNull Task<AuthResult> task) {

            if(task.isSuccessful())
            {

                Intent rIntent = new Intent(Login.this, MainActivity.class);
                startActivity(rIntent);
                finish();
            }

            else
            {
                Toast.makeText(Login.this,"You got some Error..",Toast.LENGTH_LONG).show();
            }

        }
    });
    }
}
