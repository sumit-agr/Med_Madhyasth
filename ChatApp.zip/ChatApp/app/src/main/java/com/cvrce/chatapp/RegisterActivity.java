package com.cvrce.chatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegisterActivity extends AppCompatActivity {

    private Button mBtn;
    private EditText mdisplay;
    private EditText memail;
    private EditText mpass;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        mdisplay =  (EditText)findViewById(R.id.reg_display);
        memail = (EditText) findViewById(R.id.reg_email);
        mpass = (EditText) findViewById(R.id.reg_pass);
        mBtn = (Button) findViewById(R.id.reg_btn);

        mBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String displayName = mdisplay.getText().toString();
                String email = memail.getText().toString();
                String pass = mpass.getText().toString();

                if(!TextUtils.isEmpty(displayName)||!TextUtils.isEmpty(email)||!TextUtils.isEmpty(pass))
                {
                    register_user(displayName,email,pass);
                }

            }
        });

    }

    private void register_user(String displayName, String email, String pass) {

        mAuth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful())
                {
                    Toast.makeText(RegisterActivity.this,"Successfully Registered....",Toast.LENGTH_LONG).show();
                    Intent regIntent = new Intent(RegisterActivity.this,MainActivity.class);
                    startActivity(regIntent);
                    finish();
                }
                else
                {
                    Toast.makeText(RegisterActivity.this,"You got some Error..",Toast.LENGTH_LONG).show();
                }

            }
        });


    }
}
